<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Limit extends Model
{
    use HasFactory;
    protected $hidden = [
        'user_id',
    ];
    public $timestamps = false;

    // public function user(){
    //     return $this->belongsTo('App\Models\User');
    // }
    public function expense(){
        return $this->belongsTo('App\Models\Expense');
    }
}
